#include <iostream>

using namespace std;


struct Tree { int Data; Tree *Left, *Right; };

Tree *Root;

Tree* NewTree(int Data) {
    Tree* aux = new Tree;
    aux->Data=Data;
    aux->Left = NULL;
    aux->Right = NULL;

    return aux;
}


//RSD - pre-ordine

void PreOrder(struct Tree* Root) {

    if(Root==NULL ) return;

    cout<<Root->Data<<" ";

    PreOrder(Root->Left);
    PreOrder(Root->Right);
}


//SRD - in-ordine

void InOrder (struct Tree* Root) {
    if( Root==NULL ) return;

    InOrder (Root->Left);
    cout<<Root->Data<<" ";
    InOrder(Root->Right);

}


//SDR - post-ordine

void PostOrder (struct Tree* Root) {

    if( Root==NULL ) return;

    PostOrder(Root->Left);
    PostOrder(Root->Right);

    cout<<Root->Data<<" ";
}

int main()
{
    struct Tree* Root = NewTree(1);
    Root->Left=NewTree(2);
    Root->Right=NewTree(3);
    Root->Left->Left=NewTree(4);
    Root->Left->Right=NewTree(5);

    PreOrder(Root);
    cout<<endl;
    InOrder(Root);
    cout<<endl;
    PostOrder(Root);

    return 0;
}