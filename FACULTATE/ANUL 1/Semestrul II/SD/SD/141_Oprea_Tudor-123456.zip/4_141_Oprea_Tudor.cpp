#include <iostream>
#include <string.h>
using namespace std;


struct Tree { string Data; Tree *Left, *Right; };

Tree *Root;

Tree* NewTree(string Data) {
    Tree* aux = new Tree;
    aux->Data= Data;
    aux->Left = NULL;
    aux->Right = NULL;

    return aux;
}


void InOrder (struct Tree* Root) {
    if( Root==NULL ) return;

    InOrder (Root->Left);
    cout<<Root->Data<<" ";
    InOrder(Root->Right);

}


Tree* Inserare(Tree* Node, string Data)
{
    if(Node==NULL) return NewTree(Data);

    if(Data > Node->Data)
        Node->Left = Inserare(Node->Left, Data);
    else if( Data < Node->Data)
        Node->Right= Inserare(Node->Right, Data);

    return Node;
}


int main()
{
    string c;

    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {cin>>c;
        Root=Inserare(Root,c);}
    // char s[1000];
    // cin.get(s,1000);

    // char *c=strtok(s," ");
    // while(c)
    // {
    //   Inserare(Root,c);
    //   c=strtok(NULL," ");
    // }
    //  cout<<Root->Data;
    //  Tree *start=Root;
    //     while(start)
    //         cout<<start->Data<< " ", start=start->Left;

    InOrder(Root);


    return 0;
}