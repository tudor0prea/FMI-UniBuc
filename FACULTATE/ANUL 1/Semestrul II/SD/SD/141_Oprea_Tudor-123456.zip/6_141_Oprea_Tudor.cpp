#include <iostream>
#include <fstream>
using namespace std;


struct Tree { int Data; Tree *Left, *Right; int H; };

Tree *Root;

Tree* NewTree(int Data) {
    Tree* aux = new Tree;
    aux->Data, Data;
    aux->Left = NULL;
    aux->Right = NULL;
    aux->H=1;
    return aux;
}


void PreOrder(struct Tree* Root) {

    if(Root==NULL ) return;

    cout<<Root->Data<<" ";

    PreOrder(Root->Left);
    PreOrder(Root->Right);
}

int max(int a, int b) { return (a>b)?a:b; }
int Inaltime (Tree *A) { if(A==NULL) return 0; return A->H; }
Tree* RStanga(Tree *T)
{
    Tree *a=T->Right;
    Tree *b=a->Left;

    //rotatie
    a->Left=T;
    T->Right=b;

    //inaltimi
    T->H= max(Inaltime(T->Left),Inaltime(T->Right)) +1;
    a->H =max(Inaltime(a->Left),Inaltime(a->Right))+1;
    return a;

}
Tree* RDreapta(Tree *T)
{
    Tree *a=T->Left;
    Tree *b= a->Right;

    //rotatie
    a->Right=T;
    T->Left=b;

    //inaltimi
    T->H= max(Inaltime(T->Left), Inaltime(T->Right)) +1;
    a->H =max(Inaltime(a->Left), Inaltime(a->Right))+1;
    return a;
}

int echilibrat(Tree *T) { if(T==NULL) return 0;
    return Inaltime(T->Left) - Inaltime(T->Right); }

Tree* Inserare(Tree* Node, int Data)
{
    if(Node==NULL) return NewTree(Data);

    if(Data > Node->Data)
        Node->Left = Inserare(Node->Left, Data);
    else if( Data < Node->Data)
        Node->Right= Inserare(Node->Right, Data);

    Node->H=1+max( Inaltime(Node->Left), Inaltime(Node->Right) );


    int ech = echilibrat(Node);

    //stg stg
    if( ech > 1 && Data< Node->Left->Data) return RDreapta(Node);

    //dr dr
    if( ech < -1 && Data > Node->Right->Data) return RStanga(Node);

    //dr stg
    if( ech < -1 && Data <Node->Right->Data)
    {   Node->Right=RDreapta(Node->Right);
        return RStanga(Node); }

    //stg dr
    if( ech > 1 && Data> Node->Left->Data)
    {   Node->Left=RStanga(Node->Left);
        return RDreapta(Node); }

    return Node;
}


int main()
{  int x;
    ifstream f("arbori.in");
    while(f>>x)
        Inserare( Root, x);
    // struct Tree* Root = NewTree(1);
    // Root->Left=NewTree(2);
    // Root->Right=NewTree(3);
    // Root->Left->Left=NewTree(4);
    // Root->Left->Right=NewTree(5);


    PreOrder(Root);

    return 0;
}