#include <iostream>

using namespace std;


struct Tree { int Data; Tree *Left, *Right; };

Tree *Root;

Tree* NewTree(int Data) {
    Tree* aux = new Tree;
    aux->Data=Data;
    aux->Left = NULL;
    aux->Right = NULL;

    return aux;
}


//SRD - in-ordine

void InOrder (struct Tree* Root) {
    if( Root==NULL ) return;

    InOrder (Root->Left);
    cout<<Root->Data<<" ";
    InOrder(Root->Right);

}

void ShowValues(struct Tree* Root, int k1, int k2)
{
    if( Root==NULL ) return;

    ShowValues (Root->Left, k1, k2);
    if(Root->Data <= k2 && k1<= Root->Data)
        cout<<Root->Data<<" ";
    ShowValues(Root->Right, k1, k2);
}
int main()
{
    struct Tree* Root = NewTree(1);
    Root->Left=NewTree(2);
    Root->Right=NewTree(3);
    Root->Left->Left=NewTree(4);
    Root->Left->Right=NewTree(5);

    InOrder(Root);
    cout<<endl;
    ShowValues(Root, 2, 4);

    return 0;
}