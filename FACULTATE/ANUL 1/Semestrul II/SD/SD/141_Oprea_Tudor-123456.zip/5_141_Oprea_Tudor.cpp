#include <iostream>

using namespace std;


struct Tree { int Data; Tree *Left, *Right; };

Tree *Root;

Tree* NewTree(int Data) {
    Tree* aux = new Tree;
    aux->Data=Data;
    aux->Left = NULL;
    aux->Right = NULL;

    return aux;
}


//SRD - in-ordine

void InOrder (struct Tree* Root) {
    if( Root==NULL ) return;

    InOrder (Root->Left);
    cout<<Root->Data<<" ";
    InOrder(Root->Right);

}

Tree* LowestCommonAncestor( Tree* Root, int p, int q) {
    if(Root==NULL) return NULL;

    if(Root->Data > p && Root->Data > q)
        return LowestCommonAncestor(Root->Left, p, q);

    if(Root->Data < p && Root->Data < q)
        return LowestCommonAncestor(Root->Right, p, q);

    return Root;
}
int main()
{
    struct Tree* Root = NewTree(1);
    Root->Left=NewTree(2);
    Root->Right=NewTree(3);
    Root->Left->Left=NewTree(4);
    Root->Left->Right=NewTree(5);

    InOrder(Root);
    cout<<endl;

    Tree* node=LowestCommonAncestor(Root, 2, 5);
    cout<<node->Data;

    return 0;
}