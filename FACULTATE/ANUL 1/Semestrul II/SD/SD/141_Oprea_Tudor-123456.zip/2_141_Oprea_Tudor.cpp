#include <iostream>

using namespace std;


struct Tree { int Data; Tree *Left, *Right; };

Tree *Root;

Tree* NewTree(int Data) {
    Tree* aux = new Tree;
    aux->Data=Data;
    aux->Left = NULL;
    aux->Right = NULL;

    return aux;
}


//SRD - in-ordine

void InOrder (struct Tree* Root) {
    if( Root==NULL ) return;

    InOrder (Root->Left);
    cout<<Root->Data<<" ";
    InOrder(Root->Right);

}


void StergereUltim (struct Tree* Root, struct Tree* Node)
{
    struct Tree* v[1000]={0};
    int i=1;
    v[i]=Root;


    struct Tree* aux;

    while(i)
    {
        aux=v[i];
        i--;
        if(aux==Node) { aux= NULL; delete(Node); return; }

        if(aux->Right)
            if(aux->Right == Node) {aux->Right= NULL; delete(Node); return; }
            else v[++i]=aux->Right;
        if(aux->Left)
            if(aux->Left==Node) {aux->Left= NULL; delete(Node); return; }
            else v[++i]=aux->Left;

    }
}

Tree* Stergere (struct Tree* Root, int Data)
{
    if(Root == NULL) return NULL;

    if(Root->Left == NULL)
        if(Root->Right == NULL)
            if(Root->Data==Data)
                return NULL;
            else return Root;

    struct Tree* v[1000]={0};
    int i=1;
    v[i]=Root;

    struct Tree* aux;
    struct Tree* Node= NULL;

    while(i)
    {
        aux=v[i];
        i--;

        if(aux->Data == Data) Node=aux;
        if(aux->Left) v[++i]=aux->Left;
        if(aux->Right) v[++i]=aux->Right;
    }

    if(Node!=NULL)
    {
        int j=aux->Data;
        StergereUltim(Root, aux);
        Node->Data=j;
    }
    return Root;

}
int main()
{
    struct Tree* Root = NewTree(1);
    Root->Left=NewTree(2);
    Root->Right=NewTree(3);
    Root->Left->Left=NewTree(4);
    Root->Left->Right=NewTree(5);

    InOrder(Root);

    int data=3;
    Root=Stergere(Root, data);
    cout<<endl;

    InOrder(Root);

    return 0;
}