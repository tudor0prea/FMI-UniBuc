#include <iostream>
using namespace std;
 
int part(int v[], int stg, int dr)
{
    int i, pivot = v[stg], c = 0;
    for (i = stg + 1; i <= dr; i++) {
        if (v[i] <= pivot)
            c++;
    }
 
    int ipivot = stg + c;
    swap(v[ipivot], v[stg]);
 
    int a = stg, b = dr;
 
    while (a < ipivot && b > ipivot) 
    {
 
        while (v[a] <= pivot) {
            a++;
        }
 
        while (v[b] > pivot) {
            b--;
        }
 
        if (a < ipivot && b > ipivot) {
            swap(v[a++], v[b--]);
        }
    }
 
    return ipivot;
}
 
void quickSort(int v[], int stg, int dr)
{
    if (stg >= dr)
        return;
    int m = part(v, stg, dr);
    quickSort(v, stg, m - 1);
    quickSort(v, m + 1, dr);
}
 
int main()
{
 
    int v[] = { 18, 2, 1, 5, 11, 41 };
    int n = 6;
 
    quickSort(v, 0, n - 1);
 
    for (int i = 0; i < n; i++) {
        cout << v[i] << " ";
    }
 
    return 0;
}