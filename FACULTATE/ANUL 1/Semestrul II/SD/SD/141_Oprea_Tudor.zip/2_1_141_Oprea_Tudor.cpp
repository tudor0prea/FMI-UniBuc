#include <iostream>
#include <conio.h>
using namespace std;

void MinHeap(int *v, int a, int b)
{
   int i, t;
   t= v[a];
   i = 2 * a;
   while (i <= b) {
      if (i < b && v[i+1] < v[i])
         i++;
      if (t < v[i])
         break;
      else if (t >= v[i]) {
         v[i/2] = v[i];
         i = i+i;
      }
   }
   v[i/2] = t;
   return;
}
void Construire(int *v, int n) 
{
   int i;
   for(i= n/2; i >= 1; i--) 
      MinHeap(v, i, n);
   
}


void Decapitare(int *v, int &n)

{  int i;
    swap(v[1],v[n]);
  for(i=n/2; i >= 1 ; i--)
    MinHeap(v, i, n-1);
  n--;
  return;
}


int main() 
{
   int n, i;
   
   cin>>n;
   int v[30];
   for (i = 1; i <= n; i++) 
      cin>>v[i];
   Construire(v, n);
   Decapitare(v,n);
  
   for (i = 1; i <= n; i++) 
      cout<<v[i]<<endl;
   
   return 0;
}