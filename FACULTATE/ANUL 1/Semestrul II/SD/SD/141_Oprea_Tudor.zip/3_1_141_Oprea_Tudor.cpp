#include <iostream>
using namespace std;

void InserareElement(int *A, int &n, int poz)
{
   
    for(int i=n;i>=poz+1;i--)
        A[i]=A[i-1];
    n++;
}

int main()
{ int A[1000]={1, 2, 6, 7 ,10, 12, 30}, B[500]={3, 5 ,8, 11, 29, 40}, n=7, m=5;


int indiceB=0;
for (int i=0; i < n; i++ )
   while(B[indiceB] > A[i] && B[indiceB] <=A[i+1] && indiceB<=m)
        { InserareElement(A,n,i); 
          
          A[i+1]=B[indiceB];
          indiceB++;
          
        }
    
while(indiceB<=m)
{ n++;
    A[n-1]=B[indiceB];
  indiceB++;
}

for(int i=0;i<n;i++)
cout<<A[i]<<" ";
       
       
      return 0;} 