#include <iostream>
using namespace std;

void merge(int v[], int stg, int mij, int dr)
{   int i, x, y;

    x = mij - stg + 1;
    y = dr - mij;

    int v1[x], v2[y];

        for (i = 0; i < x; i++)
            v1[i] = v[stg + i];
        for (i= 0; i < y; i++)
            v2[i] = v[mij + i + 1];
            
    int a = 0, b = 0, c = stg;

        while (a < x && b < y) 
        {
            if (v1[a] <= v2[b]) 
                v[c] = v1[a], a++;
            
            else v[c] = v2[b], b++;

        c++;
        }

        while (a < x) 
        {
            v[c] = v1[a];
            a++;
            c++;
        }

        while (b < y) 
        {
            v[c] = v2[b];
            b++;
            c++;
        }

}
void mergeSort(int v[],int stg,int dr)
{
    if(stg>=dr)
    {return;}

    int mij =stg+ (dr-stg)/2;
        mergeSort(v,stg,mij);
        mergeSort(v,mij+1,dr);
        merge(v,stg,mij,dr);
}

int main()
{
int v[] = { 19, 56, 5, 100, 78, 4 };
int n=6;

mergeSort(v, 0, n - 1);

for(int i=0; i< n; i++)
    cout<<v[i]<<" ";
return 0;
}