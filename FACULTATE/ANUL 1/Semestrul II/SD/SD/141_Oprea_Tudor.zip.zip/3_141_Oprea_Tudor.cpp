#include <iostream>
using namespace std;

struct Node { int Grade, Coef;
                Node *Next; }
                
void InmultireScalar(Node* adresa, int n)
{  
    Node* aux = *adresa;
    Node* Next;
   
   while (aux != NULL)
   {
      
      aux->Coef== (aux -> Coef) * valoare;
      aux = Next;
   }
}

int EvaluarePolinom(Node* adresa, int x)
{   int numar=0;
    Node* aux = *adresa;
    Node* Next;
   
   while (aux != NULL)
   {
      
      numar+= (aux->Coef) * ( x ** (aux -> Grade) );
      aux = Next;
   }
   return numar;
}


void SumaPolinoamelor(Node* p1, Node* p2, Node* ps)
{
    while (p1 -> Next  != NULL && p2 -> Next != NULL) 
    {
        
        if (p1->Grade > p2->Grade) 
        {
            ps->Grade = p1->Grade;
            ps->Coef = p1->Coef;
            p1 = p1-> Next;
        }
 
        else if (p2->Grade > p1->Grade) 
        {
            ps->Grade = p2->Grade;
            ps->Coef = p2->Coef;
            p2 = p2->Next;
        }
 
        else {
            ps->Grade = p1->Grade;
            ps->Coef = p1->Coef + p2->Coef;
            p1 = p1->Next;
            p2 = p2->Next;
        }
 
        // noul nod
        ps->next= new Node;
        ps = ps->next;
        ps->Next = NULL;
    }
    
    while (p1->Next!=NULL || p2->Next!=NULL) 
    {
        if (p1->Next!=NULL) 
        {
            ps->Grade = p1->Grade;
            ps->Coef = p1->Coef;
            p1 = p1->Next;
        }
        if (p2->Next!=NULL) 
        {
            ps->Grade = p2->Grade;
            ps->Coef = p2->Coef;
            p2 = p2->Next;
        }
        
        //noul nod
        ps->next= new Node;
        ps = ps->next;
        ps->Next = NULL;
    }
}