#include<iostream>
using namespace std;


struct Node { int Data; Node *Next; };

int NumarLista(Node* adresa)
{  
   int numar=0, p=1;
   Node* aux = *adresa;
   Node* Next;
   
   while (aux != NULL)
   {
      
      numar=  (aux -> Data) * p;
      p=p*10;
      aux = Next;
   }
   
   return numar;
}

int main()
{ 
    cout<< NumarLista(&head1)+NumarLista(&head2);

}
