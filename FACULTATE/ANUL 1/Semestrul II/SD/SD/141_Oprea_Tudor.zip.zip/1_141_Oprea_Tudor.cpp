#include <iostream>
using namespace std;

struct Node { int Data; Node *Next; };

//1.1

void ListaOrdonata(int nr_elemente)
{  Node *Head =new Node;
   Head->Data=0;

   int i=1;
   while(i<nr_elemente)
   {    
       Node *aux=new Node;
       aux->Data=i;
       
        aux->Next=NULL;
        *Head=aux;
       
       i++;
    }

}
//1.2
void StergereLista(Node* adresa)
{
   Node* aux = *adresa;
   Node* Next;
   
   while (aux != NULL)
   {
      Next = aux->Next;
      delete aux;
      aux = Next;
   }
   
   *adresa = NULL;
}



//1.3

void StergereElement(Node* adresa, int valoare)
{
   Node* aux = *adresa;
   Node* Next;
   
   while (aux != NULL)
   {
      
      if(Next->Data==valoare)
           { aux->Next=Next->Next;
             delete Next; 
               
           }
      aux = Next;
   }
   
}

int main()
{ int n;
  cin>>n;
    StergereElement(&head, n);

    StergereLista(&head);
 return 0;
}
