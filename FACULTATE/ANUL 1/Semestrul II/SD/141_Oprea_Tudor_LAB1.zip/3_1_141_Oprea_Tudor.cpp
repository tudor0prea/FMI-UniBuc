#include <iostream>
#include <string.h>
using namespace std;

int anagrame(char a[21], char b[21])
{ if (strlen(a)!=strlen(b))
    return 0;
  else 
  { int ok=1;
    for(int i=0;i<strlen(a);i++)
        if(strchr(a,b[i])==0)
            ok=0;
    return ok;
  }
}

int main()
{ char a[101][21];
int i, j, n;
cin>>n;
for(int i=1;i<=n;i++)
    cin>>a[i];
     
for(i=1;i<n;i++)
    for(j=i+1;j<=n;j++)
        if(anagrame(a[i],a[j]))
            swap(a[j],a[i+1]);
            
for(i=1;i<=n;i++)
    cout<<a[i]<<" ";


return 0;
}