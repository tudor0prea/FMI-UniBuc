#include <iostream>
  using namespace std;
  
  int main()
  { int i, j, v[100], n, temp;
    cin>>n;
    for(i = 0; i < n; i++)
        cin>>v[i];

   for (i = 0; i < n; i++)
   {
     j = i;
     while (j > 0 && v[j] < v[j-1])
     {
        temp = v[j];
        v[j] = v[j-1];
        v[j-1] = temp;
        j--;
      }
    }
    for(i = 0; i < n; i++)
        cout<<v[i]<<" ";
        
    return 0;
  }
  