#include <iostream>
  using namespace std;
  
  int main()
  { int i, x, v[100], n;
    cin>>x;
    cin>>n;
    for(i = 1; i <= n; i++)
        cin>>v[i];

  
    for (i = 1; i <= n ; i++)
        if(v[i]==x)
           { cout<<"gasit"; return 0;}
    
    cout<<"nu s-a gasit";
    return 0;}
 
 