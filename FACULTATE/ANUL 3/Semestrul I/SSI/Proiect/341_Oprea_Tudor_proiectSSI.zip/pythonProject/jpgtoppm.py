from PIL import Image

def png_to_ppm(input_png, output_ppm):

    img = Image.open(input_png)
    # facem un fisier .ppm cu header
    with open(output_ppm, 'wb') as ppm_file:
        ppm_file.write(b'P6\n')
        ppm_file.write(f"{img.width} {img.height}\n".encode('ascii'))
        ppm_file.write(b'255\n')

        # convertim pixelii imaginii
        ppm_file.write(img.tobytes())


input_png = 'literaT.png'
output_ppm = 'litT.ppm'
png_to_ppm(input_png, output_ppm)


input_png = 'literaU.png'
output_ppm = 'litU.ppm'
png_to_ppm(input_png, output_ppm)


input_png = 'literaD.png'
output_ppm = 'litD.ppm'
png_to_ppm(input_png, output_ppm)


input_png = 'literaO.png'
output_ppm = 'litO.ppm'
png_to_ppm(input_png, output_ppm)


input_png = 'literaR.png'
output_ppm = 'litR.ppm'
png_to_ppm(input_png, output_ppm)


