from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# criptam imaginea cu alg present
def encrypt_image_ecb(input_ppm, output_ppm, key):

    with open(input_ppm, 'rb') as ppm_file:
        ppm_content = ppm_file.read()

    # completam blocurile de 16 bytes, daca este necesar
    padding_length = 16 - (len(ppm_content) % 16)
    ppm_content += bytes([padding_length]) * padding_length

    # cream un obiect Cipher cu algoritmul AES in modul ECB
    cipher = Cipher(algorithms.AES(key), modes.ECB(), backend=default_backend())

    # cripteaza continutul imaginii
    encryptor = cipher.encryptor()
    encrypted_content = encryptor.update(ppm_content) + encryptor.finalize()

    # Sscrie continutul criptat in fisierul de iesire
    with open(output_ppm, 'wb') as output_file:
        output_file.write(encrypted_content)


input_ppm = 'litT.ppm'
output_ppm = 'encryptedT.ppm'
key = b'your_secret_key_'

encrypt_image_ecb(input_ppm, output_ppm, key)

#------------
input_ppm = 'litU.ppm'
output_ppm = 'encryptedU.ppm'

encrypt_image_ecb(input_ppm, output_ppm, key)

#------------
input_ppm = 'litD.ppm'
output_ppm = 'encryptedD.ppm'

encrypt_image_ecb(input_ppm, output_ppm, key)

#------------
input_ppm = 'litO.ppm'
output_ppm = 'encryptedO.ppm'

encrypt_image_ecb(input_ppm, output_ppm, key)


#------------
input_ppm = 'litR.ppm'
output_ppm = 'encryptedR.ppm'

encrypt_image_ecb(input_ppm, output_ppm, key)
