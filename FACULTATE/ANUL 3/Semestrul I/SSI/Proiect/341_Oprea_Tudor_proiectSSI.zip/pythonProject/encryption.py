import hashlib

input_file_name = 'headers'
output_file_name = 'headers2.txt'

hashed_lines = []

with open(input_file_name, 'r') as input_file:
    for line in input_file:
        if line.strip():
            hashed_lines.append(hashlib.sha256(line.encode('utf-8')).hexdigest())


with open(output_file_name, 'w') as output_file:
    for hashed_line in hashed_lines:
        output_file.write(hashed_line)
        output_file.write("\n")

print("ok")
