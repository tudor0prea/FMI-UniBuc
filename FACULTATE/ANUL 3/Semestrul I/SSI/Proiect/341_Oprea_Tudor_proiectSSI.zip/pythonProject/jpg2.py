from PIL import Image

def png_to_ppm(input_png, output_ppm):

    img = Image.open(input_png)
    # facem un fisier .ppm cu header
    with open(output_ppm, 'wb') as ppm_file:
        ppm_file.write(b'P6\n')
        ppm_file.write(f"{img.width} {img.height}\n".encode('ascii'))
        ppm_file.write(b'255\n')

        # convertim pixelii imaginii
        ppm_file.write(img.tobytes())



input_png = 'm.png'
output_ppm = 'M.ppm'
png_to_ppm(input_png, output_ppm)


input_png = 'a.png'
output_ppm = 'A.ppm'
png_to_ppm(input_png, output_ppm)

input_png = 'r.png'
output_ppm = 'R.ppm'
png_to_ppm(input_png, output_ppm)

input_png = 'i.png'
output_ppm = 'I.ppm'
png_to_ppm(input_png, output_ppm)
