﻿using Microsoft.AspNetCore.Mvc;
using OpreaTudor41.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace OpreaTudor41.Controllers
{
    public class TicketsController : Controller
    {

        private readonly AppDBContext db;
        public TicketsController(AppDBContext context)
        {
            db = context;
        }

        //am creat metoda index
        public IActionResult Index()
        {
            var tickets = db.Tickets.Include("Movie");

            ViewBag.tickets = tickets;

            if (TempData.ContainsKey("message"))
                ViewBag.message = TempData["message"];

            return View();
            
        }

        //am facut o metoda afisareBilete ca sa mearga si cu url ul asa, si cu /Index, chiar daca metoda e identica
        public IActionResult afisareBilete() { 

        var tickets = db.Tickets.Include("Movie");

        ViewBag.tickets = tickets;

            if (TempData.ContainsKey("message"))
                ViewBag.message = TempData["message"];

            return View("Index"); //si aceasta metoda ne duce cu view ul tot la index
         }

        //metoda new
        public IActionResult New()
        {
            Ticket bilet = new Ticket();
            bilet.Movies = GetAllMovies(); //aceasta va fi o lista cu toate filmele
            return View(bilet);
        }
        
        [HttpPost]
        public IActionResult New(Ticket requestTicket)
        {
            if (ModelState.IsValid)
            {
                db.Tickets.Add(requestTicket);
                db.SaveChanges();
                TempData["message"] = "Biletul a fost adaugat";
                return RedirectToAction("Index");
            }
            else
            {
                requestTicket.Movies = GetAllMovies();
                return View(requestTicket);
            }
        }


        //GetAllMovies pentru a putea selecta filmul unui bilet
        [NonAction]
        public IEnumerable<SelectListItem> GetAllMovies()
        {
            // facem lista de tipul SelectListItem (goala)
            var selectList = new List<SelectListItem>();

            var movies = from movie in db.Movies
                         select movie;

            // iteram prin categorii
            foreach (var film in movies)
                selectList.Add(new SelectListItem
                {
                    Value = film.Id.ToString(),
                    Text = film.DenFilm.ToString()
                });

            return selectList;
        }


        //metoda show
        public IActionResult Show(int? id)
        {
            var bilet = db.Tickets.Include("Movie").Where(c => c.Id == (int)id).First();

            if (TempData.ContainsKey("message"))
                ViewBag.message = TempData["message"];

            return View(bilet);
        }


        //metoda edit
        public IActionResult Edit(int? id)
        {
            var bilet = db.Tickets.Include("Movie").Where(c => c.Id == (int)id).First();

            bilet.Movies = GetAllMovies();
            return View(bilet);
        }
        [HttpPost]
        public IActionResult Edit(int? id, Ticket requestTicket)
        {
            var bilet = db.Tickets.Include("Movie").Where(c => c.Id == (int)id).First();
            
            if (ModelState.IsValid)
            {
                bilet.TitluBilet = requestTicket.TitluBilet;
                bilet.Data = requestTicket.Data;
                bilet.Pret = requestTicket.Pret;
                bilet.MovieId=requestTicket.MovieId;
                db.SaveChanges();
                TempData["message"] = "Biletul a fost modificat cu succes!";
                return Redirect("/Tickets/Show/" + (int)id);
            }
            else
            {
                requestTicket.Movies = GetAllMovies();
                requestTicket.Data = bilet.Data;

                return View(requestTicket);
            }
        }

        //metoda delete
        public IActionResult Delete(int? id)
        {
            var bilet = db.Tickets.Include("Movie").Where(c => c.Id == (int)id).First();
            db.Tickets.Remove(bilet);
            db.SaveChanges();

            TempData["message"] = "Biletul a fost sters";

            return RedirectToAction("Index");
        }

        //metoda search, cat am reusit din ea
        public IActionResult Search()
        {

            var tickets = db.Tickets.Include("Movie");
            var valoare = 0;
            var search = "";
            //aici da eroare daca apasam pe search
            if (Convert.ToDateTime(HttpContext.Request.Query["Data1"]) != null)
                //&& Convert.ToString(HttpContext.Request.Query["search"]) !=null)
            {
 
                //nu am facut bine tot sistemul de cautare, adica nu si conditiile
               List<int> ticketIds = db.Tickets.Where
                                        (at=>
                //                        at.Data.Value.Day == DateTime.Data1.Day  && at.Data.Value.Month == DateTime.Data1.Month && at.Data.Value.Year == DateTime.Data1.Year
                                       // && 
                                        at.Pret<valoare
                                       ).Select(a => a.Id).ToList();

                tickets = db.Tickets.Include("Movie")
                          .Where(c => ticketIds.Contains(c.Id))
                         .OrderByDescending(c => c.Pret);
            }
            ViewBag.Val = valoare;
            ViewBag.Data = search;
            ViewBag.tickets = tickets;
            return View();
        }


    }
}
