﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace OpreaTudor41.Models
{
        public class AppDBContext : DbContext
        {
            // constructorul contextului bazei de date
            public AppDBContext(DbContextOptions<AppDBContext> options) : base(options) { }

            public DbSet<Ticket> Tickets { get; set; }
            public DbSet<Movie> Movies { get; set; }
        }
}

