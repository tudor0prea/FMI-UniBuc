﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace OpreaTudor41.Models
{
    public class Ticket
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Titlul biletului este obligatoriu.")]
        [MaxLength(100, ErrorMessage ="Titlul nu poate avea mai mult de 100 de caractere.")]
        public string TitluBilet { get; set; }


        [Required(ErrorMessage = "Pretul este obligatoriu.")]

        [Range(1, 10000000000, ErrorMessage = "Pretul trebuie sa fie mai mare ca 0.")]
        public int Pret { get; set; }


        [Required(ErrorMessage = " Data biletului este obligatorie.")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Data { get; set; }

     

        [Required(ErrorMessage = "Filmul trebuie selectat")]
        public int? MovieId { get; set; }

        public virtual Movie? Movie { get; set; }

        [NotMapped]
        public IEnumerable<SelectListItem>? Movies { get; set; }
    }
}
