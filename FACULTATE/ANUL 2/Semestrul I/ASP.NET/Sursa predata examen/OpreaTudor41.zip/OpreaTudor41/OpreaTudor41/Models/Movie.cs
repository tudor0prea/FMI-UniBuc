﻿using System.ComponentModel.DataAnnotations;

namespace OpreaTudor41.Models
{
    public class Movie
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Numele filmului este obligatoriu.")]
        public string DenFilm { get; set; }

        public virtual ICollection<Ticket>? Tickets { get; set; }
    }
}
