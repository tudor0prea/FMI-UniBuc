﻿$(document).ready(function () {
    $('.summernote').summernote({
        height: 300,
        minHeight: 200,
        focus: true,
    });
});
